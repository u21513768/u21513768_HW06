﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

//<!--Quintin d' Hotman de Villiers u21513768-->
namespace HW6.Models
{
    public class Report
    {
        //public List<order> Order { get; set; }
        //public IQueryable<int> Years { get; set; }
        //public string[] Months { get; set; }
        public List<int> Totals { get; set; }
    }
}